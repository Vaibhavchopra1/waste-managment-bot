#!/usr/bin/env python3
# ROS2 Motor Controller for BTS7960B H-Bridge
# Based on custom-build-robots.com code
# Adapted for ROS2 Humble

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import RPi.GPIO as io
import time

class BTS7960MotorController(Node):
    def __init__(self):
        super().__init__('bts7960_motor_controller')
        
        # Declare parameters
        self.declare_parameter('wheel_separation', 0.20)  # Distance between wheels (meters)
        self.declare_parameter('max_speed', 0.5)  # Maximum speed (m/s)
        self.declare_parameter('pwm_frequency', 100)  # PWM frequency (Hz)
        
        # Get parameters
        self.wheel_separation = self.get_parameter('wheel_separation').value
        self.max_speed = self.get_parameter('max_speed').value
        self.pwm_freq = self.get_parameter('pwm_frequency').value
        
        # PWM_MAX gives maximum motor speed (in percent)
        self.PWM_MAX = 100
        
        # GPIO Setup - Set mode to BCM
        io.setmode(io.BCM)
        io.setwarnings(False)
        
        # --- GPIO PINS CONFIGURATION (from your test_motors.py) ---
        # Left Motor Driver
        self.L_L_EN = 16   # leftmotor_in1_pin
        self.L_R_EN = 12   # leftmotor_in2_pin
        self.L_L_PWM = 21  # leftmotorpwm_pin_l
        self.L_R_PWM = 20  # leftmotorpwm_pin_r
        
        # Right Motor Driver
        self.R_L_EN = 7    # rightmotor_in1_pin
        self.R_R_EN = 1    # rightmotor_in2_pin
        self.R_L_PWM = 25  # rightmotorpwm_pin_l
        self.R_R_PWM = 8   # rightmotorpwm_pin_r
        
        # Setup direction pins as outputs
        io.setup(self.L_L_EN, io.OUT)
        io.setup(self.L_R_EN, io.OUT)
        io.setup(self.R_L_EN, io.OUT)
        io.setup(self.R_R_EN, io.OUT)
        
        # Initialize direction pins (both enabled for bidirectional control)
        io.output(self.L_L_EN, True)
        io.output(self.L_R_EN, True)
        io.output(self.R_L_EN, True)
        io.output(self.R_R_EN, True)
        
        # Setup PWM pins as outputs
        io.setup(self.L_L_PWM, io.OUT)
        io.setup(self.L_R_PWM, io.OUT)
        io.setup(self.R_L_PWM, io.OUT)
        io.setup(self.R_R_PWM, io.OUT)
        
        # Create PWM objects
        self.leftmotorpwm_l = io.PWM(self.L_L_PWM, self.pwm_freq)
        self.leftmotorpwm_r = io.PWM(self.L_R_PWM, self.pwm_freq)
        self.rightmotorpwm_l = io.PWM(self.R_L_PWM, self.pwm_freq)
        self.rightmotorpwm_r = io.PWM(self.R_R_PWM, self.pwm_freq)
        
        # Start PWM with 0% duty cycle (motors stopped)
        self.leftmotorpwm_l.start(0)
        self.leftmotorpwm_r.start(0)
        self.rightmotorpwm_l.start(0)
        self.rightmotorpwm_r.start(0)
        
        # Subscribe to cmd_vel topic
        self.subscription = self.create_subscription(
            Twist,
            'cmd_vel',
            self.cmd_vel_callback,
            10)
        
        # Safety timer - stop motors if no command received
        self.last_cmd_time = self.get_clock().now()
        self.safety_timer = self.create_timer(0.1, self.safety_check)
        
        self.get_logger().info('BTS7960B Motor Controller initialized')
        self.get_logger().info(f'Left Motor: EN1={self.L_L_EN}, EN2={self.L_R_EN}, PWM_L={self.L_L_PWM}, PWM_R={self.L_R_PWM}')
        self.get_logger().info(f'Right Motor: EN1={self.R_L_EN}, EN2={self.R_R_EN}, PWM_L={self.R_L_PWM}, PWM_R={self.R_R_PWM}')
        self.get_logger().info('Listening to /cmd_vel for motor commands')
    
    def cmd_vel_callback(self, msg):
        """Process incoming velocity commands from teleop"""
        self.last_cmd_time = self.get_clock().now()
        
        # Extract velocities
        linear_vel = msg.linear.x   # Forward/backward (m/s)
        angular_vel = msg.angular.z # Rotation (rad/s)
        
        # Convert to differential drive wheel velocities
        left_vel = linear_vel - (angular_vel * self.wheel_separation / 2.0)
        right_vel = linear_vel + (angular_vel * self.wheel_separation / 2.0)
        
        # Normalize to [-1, 1] range
        left_power = left_vel / self.max_speed
        right_power = right_vel / self.max_speed
        
        # Clamp values
        left_power = max(-1.0, min(1.0, left_power))
        right_power = max(-1.0, min(1.0, right_power))
        
        # Set motor speeds
        self.setMotorLeft(left_power)
        self.setMotorRight(right_power)
        
        self.get_logger().debug(
            f'cmd_vel: linear={linear_vel:.2f} angular={angular_vel:.2f} -> '
            f'left={left_power:.2f} right={right_power:.2f}'
        )
    
    def setMotorLeft(self, power):
        """
        Control left motor speed and direction
        power: -1.0 (full reverse) to 1.0 (full forward)
        """
        if power < -0.01:  # Reverse
            pwm = int(abs(power) * self.PWM_MAX)
            if pwm > self.PWM_MAX:
                pwm = self.PWM_MAX
            self.leftmotorpwm_l.ChangeDutyCycle(pwm)
            self.leftmotorpwm_r.ChangeDutyCycle(0)
            self.setMotorMode("leftmotor", "reverse")
            
        elif power > 0.01:  # Forward
            pwm = int(power * self.PWM_MAX)
            if pwm > self.PWM_MAX:
                pwm = self.PWM_MAX
            self.leftmotorpwm_l.ChangeDutyCycle(0)
            self.leftmotorpwm_r.ChangeDutyCycle(pwm)
            self.setMotorMode("leftmotor", "forward")
            
        else:  # Stop
            self.leftmotorpwm_l.ChangeDutyCycle(0)
            self.leftmotorpwm_r.ChangeDutyCycle(0)
            self.setMotorMode("leftmotor", "stop")
    
    def setMotorRight(self, power):
        """
        Control right motor speed and direction
        power: -1.0 (full reverse) to 1.0 (full forward)
        """
        if power < -0.01:  # Reverse
            pwm = int(abs(power) * self.PWM_MAX)
            if pwm > self.PWM_MAX:
                pwm = self.PWM_MAX
            self.rightmotorpwm_l.ChangeDutyCycle(pwm)
            self.rightmotorpwm_r.ChangeDutyCycle(0)
            self.setMotorMode("rightmotor", "reverse")
            
        elif power > 0.01:  # Forward
            pwm = int(power * self.PWM_MAX)
            if pwm > self.PWM_MAX:
                pwm = self.PWM_MAX
            self.rightmotorpwm_l.ChangeDutyCycle(0)
            self.rightmotorpwm_r.ChangeDutyCycle(pwm)
            self.setMotorMode("rightmotor", "forward")
            
        else:  # Stop
            self.rightmotorpwm_l.ChangeDutyCycle(0)
            self.rightmotorpwm_r.ChangeDutyCycle(0)
            self.setMotorMode("rightmotor", "stop")
    
    def setMotorMode(self, motor, mode):
        """Set motor direction control pins"""
        if motor == "leftmotor":
            if mode == "reverse":
                io.output(self.L_L_EN, True)
                io.output(self.L_R_EN, False)
            elif mode == "forward":
                io.output(self.L_L_EN, False)
                io.output(self.L_R_EN, True)
            else:  # stop
                io.output(self.L_L_EN, False)
                io.output(self.L_R_EN, False)
                
        elif motor == "rightmotor":
            if mode == "reverse":
                io.output(self.R_L_EN, False)
                io.output(self.R_R_EN, True)
            elif mode == "forward":
                io.output(self.R_L_EN, True)
                io.output(self.R_R_EN, False)
            else:  # stop
                io.output(self.R_L_EN, False)
                io.output(self.R_R_EN, False)
    
    def safety_check(self):
        """Stop motors if no command received for 1 second"""
        time_since_cmd = (self.get_clock().now() - self.last_cmd_time).nanoseconds / 1e9
        if time_since_cmd > 1.0:
            self.setMotorLeft(0.0)
            self.setMotorRight(0.0)
    
    def cleanup(self):
        """Clean up GPIO on shutdown"""
        self.get_logger().info('Stopping motors and cleaning up GPIO...')
        self.setMotorLeft(0.0)
        self.setMotorRight(0.0)
        
        # Stop all PWM
        self.leftmotorpwm_l.stop()
        self.leftmotorpwm_r.stop()
        self.rightmotorpwm_l.stop()
        self.rightmotorpwm_r.stop()
        
        # Disable all outputs
        io.output(self.L_L_EN, False)
        io.output(self.L_R_EN, False)
        io.output(self.R_L_EN, False)
        io.output(self.R_R_EN, False)
        
        io.cleanup()

def main(args=None):
    rclpy.init(args=args)
    node = BTS7960MotorController()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cleanup()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

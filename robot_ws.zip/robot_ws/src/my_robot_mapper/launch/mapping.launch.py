from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import TimerAction
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    my_robot_dir = get_package_share_directory('my_robot_mapper')
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    
    # RPLidar node
    rplidar_node = Node(
        package='rplidar_ros',
        executable='rplidar_composition',
        name='rplidar_node',
        parameters=[{
            'serial_port': '/dev/ttyUSB0',
            'serial_baudrate': 115200,
            'frame_id': 'laser',
            'inverted': False,
            'angle_compensate': True,
            'scan_mode': 'Standard',
            'scan_frequency': 5.0,
        }],
        output='screen'
    )
    
    # Fake odometry publisher - REPLACES static odom->base_link transform
    fake_odom_node = Node(
        package='my_robot_mapper',
        executable='fake_odom.py',
        name='fake_odom',
        output='screen'
    )
    
    # Static TF: base_link -> laser (keep this)
    base_to_laser = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_link_to_laser',
        arguments=['0', '0', '0.1', '0', '0', '0', 'base_link', 'laser'],
        output='screen'
    )
    
    # SLAM Toolbox
    slam_params_file = os.path.join(my_robot_dir, 'config', 'mapper_params_online_async.yaml')
    
    slam_toolbox_node = TimerAction(
        period=3.0,
        actions=[
            Node(
                package='slam_toolbox',
                executable='async_slam_toolbox_node',
                name='slam_toolbox',
                output='screen',
                parameters=[
                    slam_params_file,
                    {'use_sim_time': use_sim_time}
                ],
            )
        ]
    )
    
    return LaunchDescription([
        rplidar_node,
        fake_odom_node,
        base_to_laser,
        slam_toolbox_node,
    ])

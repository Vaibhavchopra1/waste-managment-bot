from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    my_robot_dir = get_package_share_directory('my_robot_mapper')
    
    # Include the mapping launch file
    mapping_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(my_robot_dir, 'launch', 'mapping.launch.py')
        )
    )
    
    # RViz node
    rviz_config = os.path.join(my_robot_dir, 'rviz', 'mapping.rviz')
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        output='screen'
    )
    
    return LaunchDescription([
        mapping_launch,
        rviz_node,
    ])
